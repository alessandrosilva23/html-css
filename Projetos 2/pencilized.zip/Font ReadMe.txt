Pencilized (c) Brittney Murphy 2023
https://www.brittneymurphydesign.com
info@brittneymurphydesign.com

By installing or using the font(s) you agree to the following:

You may NOT redistribute the font(s) without written permission.

This font is free for personal use ONLY.

For commercial use, please purchase a license:
https://www.brittneymurphydesign.com/downloads/pencilized-font/

For more information about licensing, visit:
https://www.brittneymurphydesign.com/fonts/licensing-information/
